<?php

namespace Opdracht5;

class Teacher extends Person
{

}